const mongoose = require("mongoose");
CONNECTION_STRING = "mongodb+srv://i220991:admin@afnancluster.xfaogh6.mongodb.net/mycontacts-backend?retryWrites=true&w=majority&appName=afnancluster";
const connectDB = async () => {
    try {
        const connect = await mongoose.connect(CONNECTION_STRING);
        console.log("Database Connected:", connect.connection.host, connect.connection.name);
    } catch (err) {
        console.log(err);
        process.exit(1);
    }
}

module.exports = connectDB;