function validateForm() {
    var uname = document.getElementById("Uname");
    var email = document.getElementById("email");
    var phone = document.getElementById("phone");
    var pass = document.getElementById("Pass");
    var isValid = true;

    if (uname.value == "") {
        uname.classList.add("invalid");
        isValid = false;
    } else {
        uname.classList.remove("invalid");
    }

    if (email.value == "") {
        email.classList.add("invalid");
        isValid = false;
    } else {
        email.classList.remove("invalid");
    }

    if (phone.value == "") {
        phone.classList.add("invalid");
        isValid = false;
    } else {
        phone.classList.remove("invalid");
    }

    if (pass.value == "") {
        pass.classList.add("invalid");
        isValid = false;
    } else {
        pass.classList.remove("invalid");
    }

    if (!isValid) {
        alert("All fields must be filled out");
    }

    return isValid;
}

module.exports = validateForm;