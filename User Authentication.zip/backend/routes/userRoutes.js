const express = require('express');
const router = express.Router();

const { createUser, findUser } = require('../controllers/userController.js');

router.route("/signup").post(createUser);
router.route("/login").post(findUser);

module.exports = router;
