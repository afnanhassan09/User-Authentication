const asyncHandler = require("express-async-handler")
const nodemailer = require('nodemailer');
const bcrypt = require("bcrypt");
const User = require("../models/userModel.js");

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'hassanafnan09@gmail.com',
        pass: 'mqqz refd vdqh ibbd'
    }
});

const createUser = asyncHandler(async (req, res) => {
    let a = req.body.Uname;
    let b = req.body.Pass;
    let c = req.body.email;
    let d = req.body.Phone;
    const hashedPassword = await bcrypt.hash(b, 10);
    console.log("UserName = ", a);
    console.log("Password = ", hashedPassword);
    console.log("Email = ", c);
    console.log("Phone = ", d);
    const user = await User.create({
        name: a,
        email: c,
        password: hashedPassword,
        phone: d
    })

    const mailOptions = {
        from: 'hassanafnan09@gmail.com',
        to: c,
        subject: 'Welcome to the SignuPage!',
        html: `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body>
            <p>Dear ${a},</p>
            <p>I am thrilled to welcome you to the User Authentication community! Thank you for signing up and joining our platform. We're excited to have you on board.</p>
            <p>If you have any questions, feedback, or suggestions, please don't hesitate to reach out to us at hassanafnan09@gmail.com.</p>
            <p>Additionally, stay tuned for updates, events, and exciting announcements. We're constantly working on enhancing the user experience and bringing new opportunities to our community members.</p>
            <p>Once again, welcome to User Authentication Website! We're thrilled to have you as part of our community and look forward to connecting with you further.</p>
            <p>Best regards,</p>
            <p>Afnan Hassan<br>Senior Developer<br>User Authentication Website<br>hassanafnan09@gmail.com</p>
        </body>
        </html>
    `
    };

    transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });

    console.log("User Created = ", user);
    res.send("Received your data!");

});

const findUser = asyncHandler(async (req, res) => {
    const username = req.body.Uname;
    const password = req.body.Pass;
    const hashedPassword = await bcrypt.hash(password, 10);
    try {
        const user = await User.findOne({ name: username });

        if (user) {
            if (user.password === hashedPassword)
                res.send("Login Successfull");
            else
                res.send("wrong password");
        } else {
            res.send("No user with this username exists");
        }
    } catch (error) {
        console.error('Error finding user:', error);
        res.status(500).json({ message: 'Internal server error' });
    }

});

const SendResetCode = asyncHandler(async (req, res) => {
    const randomCode = generateRandomCode();

})

function generateRandomCode() {
    return Math.floor(Math.random() * 9000) + 1000;
}

module.exports = { createUser, findUser }
